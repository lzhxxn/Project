package odga.bt.controller;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.extern.log4j.Log4j;
import odga.bt.domain.Admin;
import odga.bt.domain.Member;
import odga.bt.domain.Support;
import odga.bt.domain.Touritems;
import odga.bt.service.AdminService;
import odga.bt.service.MemberService;
import odga.bt.service.ReviewService;
import odga.bt.vo.Chart;
import odga.bt.vo.GenderChart;

@Log4j
@Controller
@RequestMapping("/")
public class AdminController {
	@Autowired
	private AdminService service;
	@Autowired
	private MemberService mservice;

	@RequestMapping("dashboard.do")
    public ModelAndView chart() {
		List<Chart> areaC = service.areaChart();
		List<Member> memberC = service.memberChart();
		List<GenderChart> genderC = service.genderChart();
		Map<String, Object> statistic = service.getStatistics();
		List<Member> adminList = service.listAdmin();
		Touritems bestItem = service.bestTouritem();
		ModelAndView mv = new ModelAndView("dashboard","areaC",areaC);
		mv.addObject("memberC", memberC);
		mv.addObject("genderC", genderC);
		mv.addObject("statistic", statistic);
		mv.addObject("admin", adminList);
		mv.addObject("bestItem", bestItem);
		return mv;
    }
	// ȸ������Ʈ
	@RequestMapping("/memberList.do")
	public ModelAndView m_listing() {
		List<Member> m_list = service.m_listS();
		ModelAndView mv = new ModelAndView("member_list", "m_list", m_list);
			
			return mv;	
	}
   @RequestMapping("/map.do") //�ּ�
   public String map() {
      return "map"; 
   }

   @RequestMapping("/admin_info.do") //����������
   public String user() {
      return "admin_info"; 
   }
	// 회원정보 수정
	@RequestMapping(value = "/admin_info.do", method = RequestMethod.POST)
	private String updateS(Member member, @RequestParam String m_newpwd, @RequestParam MultipartFile file, HttpSession session, RedirectAttributes rttr) throws Exception {
		Member member1 = member;
		if(file.getSize()!=0) {
			   member1 = mservice.saveStore(member, file); 
			   String m_ofname = file.getOriginalFilename(); 
			   System.out.println("###"+member1.getM_fname()+m_ofname);

				member1.setM_pwd(m_newpwd);
				
				member1.setM_ofname(m_ofname);
				System.out.println("★★★★★★★★★★★업데이트★★★★★★★★★★★");
				System.out.println(member.getM_pwd());
				if(session.getAttribute("LOGINUSER") == null) {
					System.out.println("★★★★★★★★★★★로그인되어있네?★★★★★★★★★★★");
					return "redirect:../login.do";
					//return null;
				}
				session.setAttribute("LOGINUSER", mservice.updateS(member1));
				rttr.addFlashAttribute("msg", "회원정보 수정 완료");
				return "redirect:admin_info.do"; 
				//return null;
		}else {
			member1.setM_pwd(m_newpwd);
			if(session.getAttribute("LOGINUSER") == null) {
				System.out.println("★★★★★★★★★★★로그인되어있네?★★★★★★★★★★★");
					return "redirect:../login.do";
					//return null;
			}
			session.setAttribute("LOGINUSER", mservice.updateS(member1));
			rttr.addFlashAttribute("msg", "회원정보 수정 완료");
			return "redirect:admin_info.do";
			//return null;
		}
	}
	 @GetMapping("/support_list.do")
		public ModelAndView notifications() {
			List<Support> notifications = service.notificationsS();
			ModelAndView mv = new ModelAndView("support_list", "notifications", notifications);
			return mv;
		}

	   @GetMapping("/support_content.do") 
		public ModelAndView content(long s_id) {
			System.out.println("#subject: " + s_id);
			Support support = service.selectByTitle(s_id);
			System.out.println("@origin_no: " + support.getOrigin_no());
			System.out.println("@origin_no: " + support.getS_id());
			System.out.println("@origin_no: " + support.getS_content());
			System.out.println("@origin_no: " + support.getS_rdate());
			ModelAndView mv = new ModelAndView("support_content", "support", support);
			return mv;
		}
	   
	   //support_reply.jsp 
	   @GetMapping("/reply.do")
		public String reply(Support support) {
		    System.out.println("@@@@@");
			int origin_no1 = support.getOrigin_no();
			log.info("1#origin_no1: " + origin_no1);
		    support.setOrigin_no(origin_no1);
			log.info("2#origin_no1: " + origin_no1);
			return "support_reply";
		}
	   @PostMapping("/reply.do")
		public String support_reply(Support support) {
		   System.out.println("####");
		    service.insertreS(support);	
			return "redirect:support_list.do";
		}
	   

}
