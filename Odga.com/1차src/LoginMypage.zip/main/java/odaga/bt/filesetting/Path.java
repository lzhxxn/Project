package odga.bt.filesetting;

public class Path {
	public final static String FILE_STORE= "C:/coding/spring/sts-bundle/sts-3.9.11.RELEASE/workspace/Odga/src/main/webapp/resources/assets/img/profile/";
}
